//ALMUZAHIM NASEEF MUHAMAD S24B38/006 B30296
const fs = require('fs');
const bcrypt = require('bcrypt');
const readline = require('readline');

const usersFilePath = 'users.json';

// Load users from the json file
const loadUsers = () => {
    if (!fs.existsSync(usersFilePath)) {
        return { users: [] };
    }
    const data = fs.readFileSync(usersFilePath);
    return JSON.parse(data);
};

// Saving user in json
const saveUsers = (users) => {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
};

// new user
const registerUser  = async (username, password) => {
    const usersData = loadUsers();
    const existingUser  = usersData.users.find(user => user.username === username);

    if (existingUser ) {
        console.log('User  already exists. Please choose a different username.');
        return;
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    usersData.users.push({ username, password: hashedPassword });
    saveUsers(usersData);
    console.log('User  registered successfully!');
};

// Validate login credentials
const validateLogin = async (username, password) => {
    const usersData = loadUsers();
    const user = usersData.users.find(user => user.username === username);

    if (user && await bcrypt.compare(password, user.password)) {
        return true;
    }
    return false;
};

// Display the menu after login
const displayMenu = () => {
    console.log('Menu:');
    console.log('1. View Profile');
    console.log('2. Logout');
    console.log('3. Exit');
};

// Handle user input
const Input = (rl) => {
    rl.question('Choose an option: ', (option) => {
        switch (option) {
            case '1':
                console.log('Viewing profile...');
                Input(rl);
                break;
            case '2':
                console.log('Logging out...');
                rl.close();
                break;
            case '3':
                console.log('Exiting...');
                rl.close();
                break;
            default:
                console.log('Invalid option. Please try again.');
                Input(rl);
                break;
        }
    });
};


const main = async () => {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question('Do you want to (1) Register or (2) Login? ', async (choice) => {
        if (choice === '1') {
            rl.question('Enter username: ', (username) => {
                rl.question('Enter password: ', async (password) => {
                    await registerUser (username, password);
                    rl.close();
                });
            });
        } else if (choice === '2') {
            rl.question('Enter username: ', (username) => {
                rl.question('Enter password: ', async (password) => {
                    const isValid = await validateLogin(username, password);
                    if (isValid) {
                        console.log('Login successful!');
                        displayMenu();
                        Input(rl);
                    } else {
                        console.log('Invalid username or password.');
                        rl.close();
                    }
                });
            });
        } else {
            console.log('Invalid choice. Please try again.');
            rl.close();
        }
    });
};


main();